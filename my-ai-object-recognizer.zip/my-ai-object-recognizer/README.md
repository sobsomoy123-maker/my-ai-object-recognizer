# My AI Object Recognizer

A beginner-friendly, public image-classification website built with HTML/CSS/vanilla JavaScript, TensorFlow.js, MobileNet and Netlify Functions + Netlify Blobs.

## What it does

- Uses MobileNet as a pretrained feature extractor and trains a small custom neural-network classifier in the browser.
- Lets visitors capture camera examples or upload JPEG/PNG/WebP images for named categories.
- Saves sample images in Netlify Blobs, then reloads all saved examples when training.
- Publishes versioned classifier artifacts and exposes the active version to other visitors.
- Keeps the dataset and model outside the deploy bundle, so normal redeploys do not erase them.
- Supports prediction from camera frames and uploaded images, with low-confidence results labeled `Unknown`.

## Important limitations

1. **This is a public-write prototype.** There is no login or moderation. The functions validate input types, sizes, category names, and basic request rates, but IP-based rate limits are best-effort (not an atomic distributed quota). Anyone can add misleading samples or publish a structurally valid but poor/malicious model. Do not use it for private data or a critical decision. Before sharing widely, add authentication/moderation, a server-controlled training/publishing workflow, stronger quotas, and a way to review/delete samples.
2. The browser performs training, so it can take time and use substantial memory. This version limits one training run to 300 images, and the published model payload to 18 MB. Larger datasets need server-side training or batching.
3. The small dataset accuracy displayed in metadata is training accuracy, not a reliable benchmark. When every category has at least 3 examples, one example per category is held out for a small validation check. With smaller datasets, the dashboard falls back to training accuracy; this is not a reliable benchmark. Use at least 10–20 varied images per category, with different backgrounds, distances and lighting.
4. Confidence is not calibrated and is not a guarantee. The 0.50 Unknown threshold is a simple heuristic and may need adjustment.
5. MobileNet runs from public CDNs, so the first visit needs an internet connection. Camera access generally requires HTTPS (Netlify provides it) or localhost.
6. Browser-side validation checks dimensions; the server checks file signatures and byte limits, but does not fully decode every image server-side. Do not treat it as a hardened upload service.
7. Netlify Blobs are persistent for a linked/deployed site. Local development should be linked/authenticated to a Netlify site to exercise the same persistent storage. An unlinked local run may not have the same persistence behavior.

## Requirements

- Node.js 20 LTS or newer
- npm
- A Netlify account and a GitHub account for deployment

## Run locally

1. Install Node.js LTS from https://nodejs.org/ (choose the LTS download).
2. Extract `my-ai-object-recognizer.zip`.
3. Open a terminal in the extracted `my-ai-object-recognizer` folder.
4. Install packages:

   ```bash
   npm install
   ```

5. Log in to Netlify and link this folder to a site (one-time setup):

   ```bash
   npx netlify login
   npx netlify link
   ```

   Select an existing Netlify site, or create one in the Netlify dashboard first. This links local development to the site's Netlify Blobs context.
6. Start the local server:

   ```bash
   npm run dev
   ```

7. Open the local URL shown by Netlify CLI, commonly `http://localhost:8888`.

Check the site is linked if Blobs requests fail. `npm run build` runs a structural consistency check; it is not a production bundler because this site intentionally uses browser ES modules.

## Deploy with GitHub + Netlify

1. Create a new GitHub repository.
2. Put the extracted project files in the repository and push them. Example commands from the project folder:

   ```bash
   git init
   git add .
   git commit -m "Initial object recognizer"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/my-ai-object-recognizer.git
   git push -u origin main
   ```

3. In Netlify, choose **Add new site → Import an existing project**, select GitHub and choose the repository.
4. Use these settings (the `netlify.toml` file already contains them):
   - Build command: `npm run build`
   - Publish directory: `.`
   - Functions directory: `netlify/functions`
5. Deploy. No API key or paid AI API key is needed. Netlify Blobs uses the deployed site's platform context; do not set a fake storage URL or commit credentials.
6. Open the deployed HTTPS URL. Add two or more categories with at least two images each, then choose **Retrain model from all saved images**.
7. Verify persistence: add images and train; refresh; check the library and model version; open the same deployed URL on another device; deploy a small code change and verify the examples/model are still there. Do not delete/recreate the Netlify site when testing persistence.

## How to use

1. Start camera, allow camera permission, or upload an image in **Live recognition**.
2. Enter a category such as `Bottle`; capture/upload several varied images.
3. Click **Add training images**. Repeat for at least one more category.
4. Click **Retrain model from all saved images** and keep the tab open.
5. Test using a fresh image that was not used as a training example.
6. Add examples to an existing category using its **Add examples** button in the library. Retrain again to include the new images.

## Storage design

Netlify Blobs stores sample records in `object-recognizer-samples`, model versions and an `active.json` pointer in `object-recognizer-models`, category metadata in `object-recognizer-meta`, and best-effort rate-limit counters in `object-recognizer-rate-limits`. Each redeploy serves the same named stores for the same Netlify site. Model version files are kept so prior artifacts remain available, although there is no public rollback UI.

## API routes

Netlify Functions are exposed through the `/api/*` redirects in `netlify.toml`:

- `POST /api/save-sample` — validate and store one labeled sample.
- `GET /api/list-samples` — return category counts and previews.
- `GET /api/list-samples?includeImages=true` — return all training images to the browser for retraining.
- `POST /api/save-model` — store a versioned model artifact and update the active pointer.
- `GET /api/get-model` — return the active model artifact.

## Practical test checklist

- [ ] Camera starts after permission and Stop Camera ends the stream.
- [ ] Upload a valid JPEG, PNG and WebP image for prediction.
- [ ] Invalid type, too-small image, oversized image and broken image produce an error.
- [ ] Add a new category with multiple images and see its count in the library.
- [ ] Train with at least two categories and at least two images per category.
- [ ] Add examples to a previously learned category, retrain, and test both old and new categories.
- [ ] Refresh the page and verify categories, examples, and the active model load.
- [ ] Open the same deployment on a second device and verify shared categories/model.
- [ ] Deploy a code change and verify Blobs data persists.
- [ ] Try simultaneous uploads from two browsers; confirm both records appear after refresh.
- [ ] Try two simultaneous training sessions. Current public prototype does not enforce an atomic training lock; treat concurrent publishing as a known limitation and do not rely on it for production.
- [ ] Test a failed training run; the browser does not call the publish endpoint until training/serialization completes, but a public visitor can still publish a structurally valid model directly.

## Privacy and public-write warning

Anyone can read the shared training images and model, and anyone can submit images. Upload only public, non-sensitive object photos. For production, add a trusted moderator or authenticated upload flow, a server-side training queue with a single publisher, robust quotas, image decoding/scanning, deletion and rollback tools. Structural checks and IP throttling are not a substitute for access control.
